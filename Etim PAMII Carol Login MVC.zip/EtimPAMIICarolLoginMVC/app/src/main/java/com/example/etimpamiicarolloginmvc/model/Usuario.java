package com.example.etimpamiicarolloginmvc.model;

public class Usuario {

    private int id;

    private String nome;

    private String email;

    private String senha;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome(){return nome; }

    public String setNome( String nome){ this.nome = nome; }

    public String getEmail(){return email; }

    public String setEmail( String nome){ this.email = email; }

    public String getSenha(){return senha; }

    public String setSenha( String nome){ this.senha = senha; }
}




