package com.example.etimpamiicarolloginmvc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.etimpamiicarolloginmvc.R;
import com.example.etimpamiicarolloginmvc.controller.UsuarioController;
import com.example.etimpamiicarolloginmvc.model.Usuario;

public class MainActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState){
        entrar.setOnClickListener(new View.onClickListenner(){
            public void onCLick(View v){
                if (validaCampos()){
                    usuario = new Usuario();
                    controller = new UsuarioController(getApplicationContext());

                    String user = usuario.getEmail().toString();
                    String pass = usuario.getSenha().toString();

                    usuario.setEmail(user);
                    usuario.setSenha(pass);

                    boolean isCheckUSer = controller.usuarioSenha(user, pass);

                    if(!isCheckUSer){
                        Toast.makeText(MainActivity.this, "Usuario ainda não cadastardo", Toast.LENGTH_LONG).show();
                    }else{
                        Intent home = new Intent(MainActivity.this,HomeActivity.class);
                        startActivity(home);
                    }
                }
            }
        }
        );
    }

    private EditText email, senha;
    private Button entrar, criar;
    Usuario usuario;
    UsuarioController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private boolean validaCampos(){
        boolean camposValidos = true;
        if (email.getText().toString().equals("") ){
            camposValidos = false;
            email.setError("Digite o email");
            email.requestFocus();
        }
        if (senha.getText().toString().equals("") ){
            camposValidos = false;
            senha.setError("Digite a senha");
            senha.requestFocus();
        }
        return camposValidos;
    }

    private void initComponents(){
        email = findViewById(R.id.cad_edt_email);
        senha = findViewById(R.id.cad_edt_senha);
        entrar = findViewById(R.id.sign_in);
        criar = findViewById(R.id.sign_up);
    }
}